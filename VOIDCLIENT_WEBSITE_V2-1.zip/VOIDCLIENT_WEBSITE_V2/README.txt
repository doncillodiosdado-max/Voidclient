VOID CLIENT WEBSITE V2 — NEON PURPLE

This is a static website project, not a Minecraft client.
New interactive website panels:
- Player Navigation: sample target selector and compass direction preview.
- Freecam Controls: web-only toggle, camera speed slider, crosshair toggle.
- Downloads section: direct link to included Storage ESP .mcpack when that file is available.
- Responsive mobile navigation and install guide.

Open index.html in a browser to preview locally. For a public URL, upload the files in this folder to a static hosting provider (Netlify, GitHub Pages, Cloudflare Pages, etc.).

IMPORTANT: Player Navigation and Freecam controls are website UI previews only. They do not read Minecraft players or move the in-game camera. The add-on prototype has not been verified on Bedrock 26.51.
