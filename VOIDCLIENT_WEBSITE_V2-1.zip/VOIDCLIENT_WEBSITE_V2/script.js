const nav = document.getElementById('nav');
const menuToggle = document.getElementById('menuToggle');
menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

const target = document.getElementById('playerTarget');
const targetName = document.getElementById('targetName');
const directionText = document.getElementById('directionText');
const needle = document.getElementById('arrowNeedle');
const directions = {Alex:['NE · 42°',42], Steve:['SW · 225°',225], Player_03:['NW · 315°',315]};
function updateTarget(){
  const item = directions[target.value] || ['N · 0°',0];
  targetName.textContent = target.value;
  directionText.textContent = item[0];
  needle.style.transform = `rotate(${item[1]}deg)`;
}
target.addEventListener('change', updateTarget);
document.getElementById('navPreviewBtn').addEventListener('click', updateTarget);

function setSwitch(button, enabled){
  button.classList.toggle('active', enabled);
  button.setAttribute('aria-checked', String(enabled));
}
const freecamToggle = document.getElementById('freecamToggle');
const cameraPreview = document.getElementById('cameraPreview');
freecamToggle.addEventListener('click', () => {
  const enabled = freecamToggle.getAttribute('aria-checked') !== 'true';
  setSwitch(freecamToggle, enabled);
  cameraPreview.style.opacity = enabled ? '1' : '.35';
  cameraPreview.querySelector('.cam-label').textContent = enabled ? 'FREECAM · PREVIEW ON' : 'FREECAM · PREVIEW OFF';
});
const crosshairToggle = document.getElementById('crosshairToggle');
const crosshair = document.getElementById('crosshair');
crosshairToggle.addEventListener('click', () => {
  const enabled = crosshairToggle.getAttribute('aria-checked') !== 'true';
  setSwitch(crosshairToggle, enabled);
  crosshair.style.visibility = enabled ? 'visible' : 'hidden';
});
const speed = document.getElementById('cameraSpeed');
const speedValue = document.getElementById('speedValue');
speed.addEventListener('input', () => { speedValue.textContent = speed.value; });
